"""
Created on Fri 2nc Feb 2024
@author: Thomas Alscher, NHMD
"""
import json
import os
import pytz
import datetime
import importlib.resources
from . import metadataFebruary2024_v2


class metadataHandler():
    def __init__(self,metadataPath=None,**kwargs):
        """creates an instance of the metadataHandler create and modify .json metadata files

                Parameters:
                    metadataPath (string): if supplied, loads an existing .json file
                    kwargs : if metadataPath is not supplied, a new metadata dictionary is created and filled up with all keyworded arguments

        """
        if metadataPath is not None:
            with open(metadataPath, 'r') as f:
                self.__metadata = json.load(f)
        else:
            file_path = 'metadataFebruary2024_v2.json'
            with importlib.resources.open_text(__package__,file_path) as f:
                self.__metadata = json.load(f)
            timeCreated = datetime.datetime.now().astimezone(pytz.timezone('Europe/Copenhagen')).replace(microsecond=0).isoformat()
            self.__updateKey("date_metadata_created",timeCreated)
            for key in kwargs:
                self.__updateKey(key,kwargs[key])

    def __updateKey(self,key,value):
        template= metadataFebruary2024_v2.template()
        if template.checkKey(key):
            pass
        else:
            raise ValueError("Wrong key")
        if template.checkType(key,value):
            pass
        else:
            raise ValueError("Wrong value")
        self.__metadata[key]=value


    def updateKey(self,key,value):
        template = metadataFebruary2024_v2.template()
        if template.checkKey(key):
            pass
        else:
            raise ValueError("Wrong key")
        if template.checkType(key, value):
            pass
        else:
            raise ValueError("Wrong value")

    def getMetadata(self):
        return self.__metadata

    def saveMetadata(self,path):
        path, name = os.path.split(path)
        name = name[:name.find(".")]
        with open(os.path.join(path,name)+'.json', 'w') as f:
            json.dump(self.__metadata, f, indent=4)


