"""
Created on Fri 2nc Feb 2024
@author: Thomas Alscher, NHMD
"""

import cv2
class compressionHandler():
    """NOTE: this compression only affects the image; all non standard tif tags (such as thumbnail IDF, exif IDF, maker IDF, ...) are not carried over and thus lost"""
    def __init__(self,imagePath):
        self.__imagePath=imagePath

    def compressInplace(self):
        """
        compresses tif images and REPLACES them
        """
        img = cv2.imread(self.__imagePath, cv2.IMREAD_UNCHANGED)
        cv2.imwrite(self.__imagePath, img,params=(cv2.IMWRITE_TIFF_COMPRESSION, 32946))

    def compress(self,path):
        """
        compresses tif images

            Parameters: path (string): valid path to save compressed image to
        """
        img = cv2.imread(self.__imagePath, cv2.IMREAD_UNCHANGED)
        cv2.imwrite(path, img,params=(cv2.IMWRITE_TIFF_COMPRESSION, 32946))





