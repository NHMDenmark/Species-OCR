"""
Created on Fri 2nc Feb 2024
@author: Thomas Alscher, NHMD
"""

import hashlib
import os

class checksumHandler():
    def __init__(self,filePath):
        self.__file=filePath
        self.__checksum=self.createChecksum()
    def createChecksum(self):
        """
        creates two checksums of filename_source and filename_target
        Argument:   directory is directory of target file
                    filename is target filename
        Return:     checksum is the md5 checksum of target
        """
        path_source = self.__file
        with open(path_source, "rb") as f:
            file_hash_source = hashlib.md5(f.read())
        checksum = file_hash_source.hexdigest()
        return checksum

    def getChecksum(self):
        return self.__checksum

    def compareChecksum(self,checksumInput):
        """
        compares two checksums
        Argument:   checksumInput is checksum of other class
        Return:     Boolean
        """
        return self.__checksum==checksumInput





