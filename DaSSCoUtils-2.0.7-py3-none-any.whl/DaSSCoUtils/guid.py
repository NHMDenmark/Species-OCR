"""
Created on Fri 2nc Feb 2024
@author: Thomas Alscher, NHMD
"""


import random


class guidHandler():
    def __init__(self):
        self.__mapping={
            "institution":{
                "NHMD":0,
                "AU":1,
                "NHMA":2},
            "collection":{
                "": 0,
                "Vascular plants":1,
                "Entomology":2
            },
            "workstation":{
                "WORKHERB0001":0,
                "WORKHERB0002":1,
                "WORKPIOF0001":2,
                "WORKPIOF0002":3,
                "WORKHERB0003":4,
                "WORKPIOF0003":5},
        }
    def padding(self,string,padding):
        """supplies string with leading zeros

            Parameters:
                string (string): the string to be padded
                padding (int): number of digits to be shown

            Returns:
                stirng (string): modified string with leading zeros if necessary"""
        string=string[2:]
        if len(string)<padding:
            for i in range(padding-len(string)):
                string='0'+string
        return string
    def createGuid(self,strDate,strInstitution,strCollection,strWorkstation):
        """creates a unique ID (GUID) according to the following specs:
        [Date created]-[Institution]-[Collection]-[workstation]-[random number]-[unreserved digits]

            Parameters:
                    strDate (string): date of the image taken
                    strInstitution (string): institution where it was taken
                    strWorkstation (string): which workstation was it taken on
                    strCollection (string): what collection

            Returns:
                    guid_old (string): GUID
        """
        date= strDate
        institution=hex(self.__mapping["institution"][strInstitution])
        workstation=hex(self.__mapping["workstation"][strWorkstation])
        collection=hex(self.__mapping["collection"][strCollection])
        year=           hex(int(date[:4]))
        month=          hex(int(date[5:7]))
        day=            hex(int(date[8:10]))
        hour=           hex(int(date[11:13]))
        minute=         hex(int(date[14:16]))
        second=         hex(int(date[17:19]))
        random_number=  hex(random.randint(0, 999999))
        institution =   self.padding(institution,1)
        workstation =   self.padding(workstation,2)
        collection =    self.padding(collection,3)
        year =          self.padding(year,3  )
        month =         self.padding(month ,1     )
        day =           self.padding(day     ,2  )
        hour =          self.padding(hour    ,2   )
        minute =        self.padding(minute    ,2 )
        second =        self.padding(second    ,2 )
        random_number=  self.padding(random_number    ,6 )
        derivative=     self.padding(hex(0),3)
        guid=year+'-'+month+'-'+day+'-'+hour+'-'+minute+'-'+second+'-'+institution+'-'+collection+'-'+workstation+'-'+derivative+'-'+random_number+'-00000'
        return guid
