"""
Created on Fri 2nc Feb 2024
@author: Thomas Alscher, NHMD
"""

import requests
import os
import json
from http.client import HTTPConnection

class uploadHandler():
    def __init__(self,username,password):
        self.__username=username
        self.__password=password
    def verifyUser(self):
        """opens a session with the refinery server and verifies the user
        """
        URL='https://refinery.dassco.dk/verify'
        client = requests.session()
        client.get(URL)
        client.headers.update({'referer': URL})
        if 'csrftoken' in client.cookies:
            csrftoken = client.cookies['csrftoken']
        else:
            csrftoken = client.cookies['csrf']
        data_dict = dict(
            username=str(self.__username),
            password=str(self.__password),
            csrfmiddlewaretoken=csrftoken,
            next='/')
        response = client.post(URL, data=data_dict)
        token=response.content.decode('ascii')
        if response.status_code==200:
            return True,token
        else:
            return False, token


    def upload(self,checksum,metadata,assetName,imagePath):
        """creates the POST statement

        :param checksum (string): string of the checksum of image
        :param metadata (dictionary): dictionary containing the metadata
        :param assetName (string): name of the asset
        :param imagePath (string): path to the image that gets uploaded
        :return: HTTPS status code
        """
        HTTPConnection.__init__.__defaults__ = tuple(
            x if x != 8192 else 64 * 1024
            for x in HTTPConnection.__init__.__defaults__
        )
        '''creates post statement'''
        URL='https://refinery.dassco.dk/upload'
        client = requests.session()
        client.get(URL)
        client.headers.update({'referer': URL})

        if 'csrftoken' in client.cookies:
            csrftoken = client.cookies['csrftoken']
        else:
            csrftoken = client.cookies['csrf']

        metadata_dict = metadata



        data_dict = dict(
            username=str(self.__username),
            password=str(self.__password),
            content_type='image',
            name=assetName,
            metadata=json.dumps(metadata_dict),
            csrfmiddlewaretoken=csrftoken,
            checksum=checksum,
            size= str(os.stat(imagePath).st_size),
            next='/')
        f = dict(media=open(imagePath, 'rb'))
        response = client.post(URL, data=data_dict, files=f)
        return response.status_code


    def uploadTest(self,checksum,metadata,assetName,imagePath):
        HTTPConnection.__init__.__defaults__ = tuple(
            x if x != 8192 else 64 * 1024
            for x in HTTPConnection.__init__.__defaults__
        )
        '''creates post statement'''
        URL='https://refinery.dassco.dk/upload_test'
        client = requests.session()
        client.get(URL)
        client.headers.update({'referer': URL})

        if 'csrftoken' in client.cookies:
            csrftoken = client.cookies['csrftoken']
        else:
            csrftoken = client.cookies['csrf']

        metadata_dict = metadata



        data_dict = dict(
            username=str(self.__username),
            password=str(self.__password),
            content_type='image',
            name=assetName,
            metadata=json.dumps(metadata_dict),
            csrfmiddlewaretoken=csrftoken,
            checksum=checksum,
            size= str(os.stat(imagePath).st_size),
            next='/')
        f = dict(media=open(imagePath, 'rb'))
        response = client.post(URL, data=data_dict, files=f)
        return response.status_code