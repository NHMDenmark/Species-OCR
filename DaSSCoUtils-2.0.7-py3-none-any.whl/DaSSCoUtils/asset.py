import os
import cv2
class assetHandler():
    def __init__(self,metadataPath,imagePath=None,imagePathRaw=None):
        self.__imagePath=imagePath
        self.__metadataPath=metadataPath
        self.__imagePathRaw=imagePathRaw
        self.updatedAsset=False
        self.newAsset=False

    def getImage(self):
        return cv2.imread(self.__imagePath, cv2.IMREAD_UNCHANGED)

    def getImageRawPath(self):
        return self.__imagePathRaw
    
    def getImagePath(self):
        return self.__imagePath

    def setImage(self,imagePath):
        self.__imagePath=imagePath
        self.__newAsset=True

    def setImageRaw(self,imagePathRaw):
        self.__imagePathRaw=imagePathRaw

    def getMetadata(self):
        return self.__metadataPath

    def deleteAsset(self):
        if self.__imagePathRaw is not None:
            os.remove(self.__imagePathRaw)
            self.__imagePathRaw=None
        if self.__imagePath is not None:
            os.remove(self.__imagePath)
            self.__imagePath=None
        os.remove(self.__metadataPath)
        self.__metadataPath=None

    def moveAsset(self,directory):
        if self.__imagePathRaw is not None:
            os.rename(self.__imagePathRaw,os.path.join(directory,os.path.split(self.__imagePathRaw)[1]))
            self.__imagePathRaw=os.path.join(directory,os.path.split(self.__imagePathRaw)[1])
        if self.__imagePath is not None:
            os.rename(self.__imagePath,os.path.join(directory,os.path.split(self.__imagePath)[1]))
            self.__imagePath=os.path.join(directory,os.path.split(self.__imagePath)[1])
        os.rename(self.__metadataPath, os.path.join(directory, os.path.split(self.__metadataPath)[1]))
        self.__metadataPath=os.path.join(directory, os.path.split(self.__metadataPath)[1])

    def renameAsset(self,name):
        if self.__imagePathRaw is not None:
            directory, filename = os.path.split(self.__imagePathRaw)
            fileformat = filename[filename.find("."):]
            os.rename(self.__imagePathRaw, os.path.join(directory, name+fileformat))
        if self.__imagePath is not None:
            directory, filename = os.path.split(self.__imagePath)
            fileformat = filename[filename.find("."):]
            os.rename(self.__imagePath, os.path.join(directory, name+fileformat))
        directory, filename = os.path.split(self.__metadataPath)
        fileformat = filename[filename.find("."):]
        os.rename(self.__metadataPath, os.path.join(directory, name + fileformat))

