import re


class dateHandler():
    def __init__(self):
        self.pattern = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[-+]\d{2}:\d{2}$')
    def __call__(self,input):
        if isinstance(input,str):
            if bool(self.pattern.match(input)):
                return True
            else:
                return False
        elif input is None:
            return True
        else:
            return False

class enum1():
    "file_format"
    def __init__(self):
        self.list=["tif","jpeg","raf"]
    def __call__(self,input):
        if isinstance(input,str):
            if input in self.list:
                return True
            else:
                return False
        else:
            return False
class enum2():
    "status"
    def __init__(self):
        self.list=["",
                   "For processing",
                   "being processed",
                   "working copy",
                   "archive",
                   "processing halted",
                   "for deletion",
                   "issue with media",
                   "issue with metadata"]
    def __call__(self,input):
        if isinstance(input,str):
            if input in self.list:
                return True
            else:
                return False
        else:
            return False

class event():
    "dummy class for northtec events"
    def __init__(self):
        pass
    def __call__(self,input):
        return True

class listOfStrings():
    def __init__(self):
        pass
    def __call__(self,input):
        switch=True
        if isinstance(input,list):
            for l in input:
                if isinstance(l,str):
                    pass
                else:
                    switch=False
        elif isinstance(input,str):
            return True
        else:
            switch=False
        return switch


class template():
    def __init__(self):
        self.metadata={"asset_created_by":str,
        "asset_deleted_by":str,
        "asset_guid":str,
        "asset_pid":str,
        "asset_subject":str,
        "date_asset_taken":dateHandler,
        "asset_updated_by":str,
        "audited":bool,
        "audited_by":str,
        "audited_date":dateHandler,
        "barcode":listOfStrings,
        "collection":str,
        "date_asset_created":dateHandler,
        "date_asset_deleted":dateHandler,
        "date_asset_finalised":dateHandler,
        "date_asset_updated":dateHandler,
        "date_metadata_created":dateHandler,
        "date_metadata_updated":event,
        "date_metadata_uploaded":event,
        "digitiser":str,
        "external_publisher":listOfStrings,
        "file_format":enum1,
        "funding":str,
        "institution":str,
        "metadata_created_by":str,
        "metadata_updated_by":event,
        "metadata_uploaded_by":event,
        "multispecimen":bool,
        "parent_guid":str,
        "payload_type":listOfStrings,
        "pipeline_name":str,
        "preparation_type":str,
        "pushed_to_specify_date":dateHandler,
        "restricted_access":listOfStrings,
        "specimen_pid":str,
        "status":enum2,
        "tags":dict,
        "workstation_name":str}

    def checkKey(self,key):
        if key in self.metadata:
            return True
        else:
            return False
    def checkType(self,key,value):
        if self.metadata[key]==dateHandler:
            d=dateHandler()
            return d(value)
        elif self.metadata[key]==enum1:
            e=enum1()
            return e(value)
        elif self.metadata[key]==enum2:
            e = enum2()
            return e(value)
        elif self.metadata[key]==listOfStrings:
            p = listOfStrings()
            return p(value)
        elif self.metadata[key]==event:
            e = event()
            return e(value)
        elif type(value)==self.metadata[key]:
            return True
        else:
            return False


